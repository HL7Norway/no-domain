# no-blood-pressure-create - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-blood-pressure-create**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](#) 
*  [XML](Observation-no-blood-pressure-create.xml.md) 
*  [JSON](Observation-no-blood-pressure-create.json.md) 
*  [TTL](Observation-no-blood-pressure-create.ttl.md) 

## Example Observation: no-blood-pressure-create

version: 0; Last updated: 2014-01-30 22:35:23+1100; 

Information Source: [HL7_Norway](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://fhir.org/packages/hl7.fhir.no.basis/HL7_Norway)

Profile: [no-domain-VitalSigns-Observation-bloodpressure Profile](StructureDefinition-no-domain-VitalSigns-Observation-bloodpressure.md)

**NoDomainVitalSignsBloodpressureBodyPosition-Extension**: [SNOMED CT 4801000202104](http://snomed.info/id/4801000202104): Liggende

**NoDomainVitalSignsCuffSize-Extension**: [SNOMED CT 720740000](http://snomed.info/id/720740000): Lår voksne

**NoDomainVitalSignsSleepStatus-Extension**: [SNOMED CT 248218005](http://snomed.info/id/248218005): Våken

**NoDomainVitalSignsTilt-Extension**: 14 deg

**NoDomainVitalSignsBloodpressureSystolicFormula-Extension**: sample formula 1

**NoDomainVitalSignsBloodpressureDiastolicFormula-Extension**: sample formula 2

**NoDomainVitalSignsBloodpressureMeanArterialFormula-Extension**: sample formula 3

**status**: Final

**category**: Vital Signs

**code**: BP pnl w all optional

**subject**: [Anonymous Patient (no stated gender), DoB Unknown ( urn:oid:2.16.578.1.12.4.1.4.1#1000808)](Patient-cdp1000808.md)

**effective**: 2021-05-10

**performer**: 

* [PractitionerRole: identifier = urn:oid:1.3.6.1.4.1.9038.51.1#104](PractitionerRole-agb104.md)
* [Organization: identifier = urn:oid:1.3.6.1.4.1.9038.70.3#23](Organization-afa23.md)

**note**: 

> 

Demo Blood Pressure


**bodySite**: Finger

**method**: Auskultasjon

> **component****code**:Systolic blood pressure**value**: 123 mm[Hg](Details: UCUM codemm[Hg] = 'mm[Hg]')

### ReferenceRanges

| | | |
| :--- | :--- | :--- |
| - | **Low** | **High** |
| * | 120 mm[Hg] | 139 mm[Hg] |


> **component****code**:Diastolic blood pressure**value**: 78 mm[Hg](Details: UCUM codemm[Hg] = 'mm[Hg]')

### ReferenceRanges

| | | |
| :--- | :--- | :--- |
| - | **Low** | **High** |
| * | 60 mm[Hg] | 89 mm[Hg] |


> **component****code**:Mean blood pressure**value**: 93 mm[Hg](Details: UCUM codemm[Hg] = 'mm[Hg]')

### ReferenceRanges

| | | |
| :--- | :--- | :--- |
| - | **Low** | **High** |
| * | 60 mm[Hg] | 100 mm[Hg] |


 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

