# no-body-height-create - JSON Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-body-height-create**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](Observation-no-body-height-create.md) 
*  [XML](Observation-no-body-height-create.xml.md) 
*  [JSON](#) 
*  [TTL](Observation-no-body-height-create.ttl.md) 

## : no-body-height-create - JSON Representation

[Raw json](Observation-no-body-height-create.json) | [Download](Observation-no-body-height-create.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

