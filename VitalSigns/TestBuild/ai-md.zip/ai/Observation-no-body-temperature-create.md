# no-body-temperature-create - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-body-temperature-create**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](#) 
*  [XML](Observation-no-body-temperature-create.xml.md) 
*  [JSON](Observation-no-body-temperature-create.json.md) 
*  [TTL](Observation-no-body-temperature-create.ttl.md) 

## Example Observation: no-body-temperature-create

version: 0; Last updated: 2014-01-30 22:35:23+1100; 

Information Source: [HL7_Norway](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://fhir.org/packages/hl7.fhir.no.basis/HL7_Norway)

Profile: [no-domain-VitalSigns-Observation-bodytemp Profile](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.md)

**NoDomainVitalSignsBodyExposure-Extension**: [SNOMED CT 5671000202107](http://snomed.info/id/5671000202107): Naken

**NoDomainVitalSignsActiveHeating-Extension**: active heating sample

**NoDomainVitalSignsDaysSinceMenstruationStart-Extension**: 12

**status**: Final

**category**: Vital Signs

**code**: Body temperature

**subject**: Identifier: `urn:oid:2.16.578.1.12.4.1.4.1`/1000239

**effective**: 2021-05-10

**performer**: 

* Identifier: `urn:oid:2.16.578.1.12.4.1.2`/889911
* [Organization: identifier = urn:oid:1.3.6.1.4.1.9038.70.3#23](Organization-afa23.md)

**value**: 37 Cel(Details: UCUM codeCel = 'Cel')

**note**: 

> 

Demo Body Temperature


**bodySite**: Endetarm

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

