#  - v0.9.5

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](Observation-no-heart-rate-create.md) 
*  [XML](Observation-no-heart-rate-create.xml.md) 
*  [JSON](Observation-no-heart-rate-create.json.md) 
*  [TTL](Observation-no-heart-rate-create.ttl.md) 

## : Observation/no-heart-rate-create - Change History

History of changes for no-heart-rate-create .

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

