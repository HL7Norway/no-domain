#  - v1.0.0

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](Observation-no-oxygen-saturation-create.md) 
*  [XML](Observation-no-oxygen-saturation-create.xml.md) 
*  [JSON](Observation-no-oxygen-saturation-create.json.md) 
*  [TTL](Observation-no-oxygen-saturation-create.ttl.md) 

## : Observation/no-oxygen-saturation-create - Change History

History of changes for no-oxygen-saturation-create .

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

