# no-oxygen-saturation-create - XML Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-oxygen-saturation-create**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](Observation-no-oxygen-saturation-create.md) 
*  [XML](#) 
*  [JSON](Observation-no-oxygen-saturation-create.json.md) 
*  [TTL](Observation-no-oxygen-saturation-create.ttl.md) 

## : no-oxygen-saturation-create - XML Representation

[Raw xml](Observation-no-oxygen-saturation-create.xml) | [Download](Observation-no-oxygen-saturation-create.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

