# no-pulse-rate - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-pulse-rate**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](#) 
*  [XML](Observation-no-pulse-rate.xml.md) 
*  [JSON](Observation-no-pulse-rate.json.md) 
*  [TTL](Observation-no-pulse-rate.ttl.md) 

## Example Observation: no-pulse-rate

version: 0; Last updated: 2014-01-30 22:35:23+1100; 

Information Source: [HL7_Norway](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://fhir.org/packages/hl7.fhir.no.basis/HL7_Norway)

Profile: [no-domain-VitalSigns-Observation-pulse Profile](StructureDefinition-no-domain-VitalSigns-Observation-pulse.md)

**NoDomainVitalSignsPulseRhythm-Extension**: [SNOMED CT 271636001](http://snomed.info/id/271636001): Regelmessig

**NoDomainVitalSignsConfoundingFactor-Extension**: sample confounding factor

**NoDomainVitalSignsPulseRhythmIrregularity-Extension**: [SNOMED CT 271638000](http://snomed.info/id/271638000): Regelmessig uregelmessig

**NoDomainVitalSignsClinicalDescription-Extension**: 

> 

Clinical description sample


**NoDomainVitalSignsHeartRatePulseBodyPosition-Extension**: [SNOMED CT 33586001](http://snomed.info/id/33586001): Sittende

**status**: Final

**category**: Vital Signs

**code**: Heart rate

**subject**: [Anonymous Patient (no stated gender), DoB Unknown ( urn:oid:2.16.578.1.12.4.1.4.1#1000240)](Patient-cdp1000240.md)

**effective**: 2021-05-10

**performer**: 

* Identifier: `urn:oid:2.16.578.1.12.4.1.2`/889911
* [Organization: identifier = urn:oid:1.3.6.1.4.1.9038.70.3#23](Organization-afa23.md)

**value**: 61 /min(Details: UCUM code/min = '/min')

**note**: 

> 

Demo Pulse Rate


**bodySite**: Tå

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

