# no-pulse-rate - TTL Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-pulse-rate**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](Observation-no-pulse-rate.md) 
*  [XML](Observation-no-pulse-rate.xml.md) 
*  [JSON](Observation-no-pulse-rate.json.md) 
*  [TTL](#) 

## : no-pulse-rate - TTL Representation

[Raw ttl](Observation-no-pulse-rate.ttl) | [Download](Observation-no-pulse-rate.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

