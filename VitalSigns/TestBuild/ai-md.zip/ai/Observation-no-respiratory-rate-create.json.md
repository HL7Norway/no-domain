# no-respiratory-rate-create - JSON Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-respiratory-rate-create**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](Observation-no-respiratory-rate-create.md) 
*  [XML](Observation-no-respiratory-rate-create.xml.md) 
*  [JSON](#) 
*  [TTL](Observation-no-respiratory-rate-create.ttl.md) 

## : no-respiratory-rate-create - JSON Representation

[Raw json](Observation-no-respiratory-rate-create.json) | [Download](Observation-no-respiratory-rate-create.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

