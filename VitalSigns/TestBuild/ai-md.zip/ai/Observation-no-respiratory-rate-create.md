# no-respiratory-rate-create - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-respiratory-rate-create**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](#) 
*  [XML](Observation-no-respiratory-rate-create.xml.md) 
*  [JSON](Observation-no-respiratory-rate-create.json.md) 
*  [TTL](Observation-no-respiratory-rate-create.ttl.md) 

## Example Observation: no-respiratory-rate-create

version: 0; Last updated: 2014-01-30 22:35:23+1100; 

Information Source: [HL7_Norway](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://fhir.org/packages/hl7.fhir.no.basis/HL7_Norway)

Profile: [no-domain-VitalSigns-Observation-respirationrate Profile](StructureDefinition-no-domain-VitalSigns-Observation-respirationrate.md)

**NoDomainVitalSignsRespirationRateBodyPosition-Extension**: [SNOMED CT 10904000](http://snomed.info/id/10904000): oppreist stilling

**NoDomainVitalSignsRespirationRegularity-Extension**: [SNOMED CT 276888009](http://snomed.info/id/276888009): Regelmessig

**NoDomainVitalSignsRespirationDepth-Extension**: [SNOMED CT 301284009](http://snomed.info/id/301284009): Normal

**NoDomainVitalSignsClinicalDescription-Extension**: 

> 

Description of Respiration


**NoDomainVitalSignsSpontaneousBreathing-Extension**: [SNOMED CT 241700002](http://snomed.info/id/241700002): Tilstede

> **NoDomainVitalSignsInspiredOxygen-Extension**
* http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsFlowExtension: 6100 ml/min
* http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsFiO2Extension: 21/100
* http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsPercentO2Extension: 21/100
* http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsOnAirExtension: true
* http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsMethodofOxygenDeliveryExtension: Maske

**NoDomainVitalSignsConfoundingFactor-Extension**: sample confounding factor

**status**: Final

**category**: Vital Signs

**code**: Respiratory rate

**subject**: [Anonymous Patient (no stated gender), DoB Unknown ( urn:oid:2.16.578.1.12.4.1.4.1#1000240)](Patient-cdp1000240.md)

**effective**: 2021-05-10

**performer**: 

* [PractitionerRole: identifier = urn:oid:1.3.6.1.4.1.9038.51.1#30](PractitionerRole-agb30.md)
* [Organization: identifier = urn:oid:1.3.6.1.4.1.9038.70.3#23](Organization-afa23.md)

**value**: 14 /min(Details: UCUM code/min = '/min')

**interpretation**: Clinical interpretation of Respiration

**note**: 

> 

Demo Respiration


 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

