# no-respiratory-rate-create - TTL Representation - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-respiratory-rate-create**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](Observation-no-respiratory-rate-create.md) 
*  [XML](Observation-no-respiratory-rate-create.xml.md) 
*  [JSON](Observation-no-respiratory-rate-create.json.md) 
*  [TTL](#) 

## : no-respiratory-rate-create - TTL Representation

[Raw ttl](Observation-no-respiratory-rate-create.ttl) | [Download](Observation-no-respiratory-rate-create.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

