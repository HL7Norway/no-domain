# Organization details of afa23 - TTL Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Organization details of afa23**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](Organization-afa23.md) 
*  [XML](Organization-afa23.xml.md) 
*  [JSON](Organization-afa23.json.md) 
*  [TTL](#) 

## : Organization details of afa23 - TTL Representation

[Raw ttl](Organization-afa23.ttl) | [Download](Organization-afa23.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

