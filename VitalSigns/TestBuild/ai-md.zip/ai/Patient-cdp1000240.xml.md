# Patient details of cdp1000240 - XML Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient details of cdp1000240**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](Patient-cdp1000240.md) 
*  [XML](#) 
*  [JSON](Patient-cdp1000240.json.md) 
*  [TTL](Patient-cdp1000240.ttl.md) 

## : Patient details of cdp1000240 - XML Representation

[Raw xml](Patient-cdp1000240.xml) | [Download](Patient-cdp1000240.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

