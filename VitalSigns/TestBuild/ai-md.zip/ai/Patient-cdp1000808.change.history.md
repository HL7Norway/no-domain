#  - v1.0.0

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](Patient-cdp1000808.md) 
*  [XML](Patient-cdp1000808.xml.md) 
*  [JSON](Patient-cdp1000808.json.md) 
*  [TTL](Patient-cdp1000808.ttl.md) 

## : Patient/cdp1000808 - Change History

History of changes for cdp1000808 .

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

