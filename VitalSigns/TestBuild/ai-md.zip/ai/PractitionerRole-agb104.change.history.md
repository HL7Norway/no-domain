#  - v1.0.0

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](PractitionerRole-agb104.md) 
*  [XML](PractitionerRole-agb104.xml.md) 
*  [JSON](PractitionerRole-agb104.json.md) 
*  [TTL](PractitionerRole-agb104.ttl.md) 

## : PractitionerRole/agb104 - Change History

History of changes for agb104 .

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

