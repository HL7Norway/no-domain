# Practioner details of agb104 - JSON Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Practioner details of agb104**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](PractitionerRole-agb104.md) 
*  [XML](PractitionerRole-agb104.xml.md) 
*  [JSON](#) 
*  [TTL](PractitionerRole-agb104.ttl.md) 

## : Practioner details of agb104 - JSON Representation

[Raw json](PractitionerRole-agb104.json) | [Download](PractitionerRole-agb104.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

