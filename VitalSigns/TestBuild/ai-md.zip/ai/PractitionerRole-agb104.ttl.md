# Practioner details of agb104 - TTL Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Practioner details of agb104**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](PractitionerRole-agb104.md) 
*  [XML](PractitionerRole-agb104.xml.md) 
*  [JSON](PractitionerRole-agb104.json.md) 
*  [TTL](#) 

## : Practioner details of agb104 - TTL Representation

[Raw ttl](PractitionerRole-agb104.ttl) | [Download](PractitionerRole-agb104.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

