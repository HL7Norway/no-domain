# PractitionerRole details of agb30 - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PractitionerRole details of agb30**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](#) 
*  [XML](PractitionerRole-agb30.xml.md) 
*  [JSON](PractitionerRole-agb30.json.md) 
*  [TTL](PractitionerRole-agb30.ttl.md) 

## Example PractitionerRole: PractitionerRole details of agb30

**identifier**: `urn:oid:1.3.6.1.4.1.9038.51.1`/30

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

