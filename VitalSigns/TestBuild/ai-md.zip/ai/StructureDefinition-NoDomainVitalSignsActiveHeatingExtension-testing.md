# NoDomainVitalSignsActiveHeating-Extension - Testing - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsActiveHeating-Extension**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsActiveHeatingExtension - Testing

| |
| :--- |
| Draft as of 2025-01-28 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

