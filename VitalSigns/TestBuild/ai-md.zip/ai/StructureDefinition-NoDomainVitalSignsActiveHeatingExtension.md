# NoDomainVitalSignsActiveHeating-Extension - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsActiveHeating-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsActiveHeating-Extension 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsActiveHeatingExtension | *Version*:0.9.5 |
| Draft as of 2025-01-28 | *Computable Name*:NoDomainVitalSignsActiveHeatingExtension |

description of the conditions applied

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [no-domain-VitalSigns-Observation-bodytemp Profile](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.md)
* Examples for this Extension: [Observation/no-body-temperature-create](Observation-no-body-temperature-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/NoDomainVitalSignsActiveHeatingExtension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type string: description of the conditions applied

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type string: description of the conditions applied

 

Other representations of profile: [CSV](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.csv), [Excel](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.xlsx), [Schematron](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.sch) 

#### Constraints

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

