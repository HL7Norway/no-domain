# NoDomainVitalSignsBloodpressureBodyPosition-Extension - TTL Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsBloodpressureBodyPosition-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsBloodpressureBodyPositionExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsBloodpressureBodyPositionExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsBloodpressureBodyPositionExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsBloodpressureBodyPositionExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsBloodpressureBodyPositionExtension.profile.json.md) 
*  [TTL](#) 

## Extension: NoDomainVitalSignsBloodpressureBodyPositionExtension - TTL Profile

| |
| :--- |
| Draft as of 2025-01-28 |

TTL representation of the NoDomainVitalSignsBloodpressureBodyPositionExtension extension.

[Raw ttl](StructureDefinition-NoDomainVitalSignsBloodpressureBodyPositionExtension.ttl) | [Download](StructureDefinition-NoDomainVitalSignsBloodpressureBodyPositionExtension.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

