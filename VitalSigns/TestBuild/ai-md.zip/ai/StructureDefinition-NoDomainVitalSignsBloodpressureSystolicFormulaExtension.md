# NoDomainVitalSignsBloodpressureSystolicFormula-Extension - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsBloodpressureSystolicFormula-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsBloodpressureSystolicFormulaExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsBloodpressureSystolicFormulaExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsBloodpressureSystolicFormulaExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsBloodpressureSystolicFormulaExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsBloodpressureSystolicFormulaExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsBloodpressureSystolicFormula-Extension 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsBloodpressureSystolicFormulaExtension | *Version*:1.0.0 |
| Draft as of 2025-01-28 | *Computable Name*:NoDomainVitalSignsBloodpressureSystolicFormulaExtension |

Formula used to calculate the pressure.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [no-domain-VitalSigns-Observation-bloodpressure Profile](StructureDefinition-no-domain-VitalSigns-Observation-bloodpressure.md)
* Examples for this Extension: [Observation/no-blood-pressure-create](Observation-no-blood-pressure-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/NoDomainVitalSignsBloodpressureSystolicFormulaExtension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type string: Formula used to calculate the pressure.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type string: Formula used to calculate the pressure.

 

Other representations of profile: [CSV](StructureDefinition-NoDomainVitalSignsBloodpressureSystolicFormulaExtension.csv), [Excel](StructureDefinition-NoDomainVitalSignsBloodpressureSystolicFormulaExtension.xlsx), [Schematron](StructureDefinition-NoDomainVitalSignsBloodpressureSystolicFormulaExtension.sch) 

#### Constraints

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

