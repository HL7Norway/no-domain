# NoDomainVitalSignsBodyExposure-Extension - Testing - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsBodyExposure-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsBodyExposureExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsBodyExposureExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsBodyExposureExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsBodyExposureExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsBodyExposureExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsBodyExposureExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsBodyExposureExtension - Testing

| |
| :--- |
| Draft as of 2025-01-28 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

