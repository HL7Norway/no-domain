# NoDomainVitalSignsBodyHeightBodyPosition-Extension - TTL Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsBodyHeightBodyPosition-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsBodyHeightBodyPositionExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsBodyHeightBodyPositionExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsBodyHeightBodyPositionExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsBodyHeightBodyPositionExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsBodyHeightBodyPositionExtension.profile.json.md) 
*  [TTL](#) 

## Extension: NoDomainVitalSignsBodyHeightBodyPositionExtension - TTL Profile

| |
| :--- |
| Draft as of 2025-01-28 |

TTL representation of the NoDomainVitalSignsBodyHeightBodyPositionExtension extension.

[Raw ttl](StructureDefinition-NoDomainVitalSignsBodyHeightBodyPositionExtension.ttl) | [Download](StructureDefinition-NoDomainVitalSignsBodyHeightBodyPositionExtension.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

