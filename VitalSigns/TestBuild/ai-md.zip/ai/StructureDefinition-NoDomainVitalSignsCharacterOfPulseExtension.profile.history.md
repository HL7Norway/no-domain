#  - v0.9.5

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsCharacterOfPulseExtension - Change History

| |
| :--- |
| Draft as of 2025-01-28 |

Changes in the NoDomainVitalSignsCharacterOfPulseExtension extension.

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

