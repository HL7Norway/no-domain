# NoDomainVitalSignsCharacterOfPulse-Extension - JSON Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsCharacterOfPulse-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsCharacterOfPulseExtension - JSON Profile

| |
| :--- |
| Draft as of 2025-01-28 |

JSON representation of the NoDomainVitalSignsCharacterOfPulseExtension extension.

[Raw json](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.json) | [Download](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

