# NoDomainVitalSignsCharacterOfPulse-Extension - TTL Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsCharacterOfPulse-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.profile.json.md) 
*  [TTL](#) 

## Extension: NoDomainVitalSignsCharacterOfPulseExtension - TTL Profile

| |
| :--- |
| Draft as of 2025-01-28 |

TTL representation of the NoDomainVitalSignsCharacterOfPulseExtension extension.

[Raw ttl](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.ttl) | [Download](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

