# NoDomainVitalSignsCharacterOfPulse-Extension - XML Representation - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsCharacterOfPulse-Extension**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsCharacterOfPulseExtension - XML Profile

| |
| :--- |
| Draft as of 2025-01-28 |

XML representation of the NoDomainVitalSignsCharacterOfPulseExtension extension.

[Raw xml](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.xml) | [Download](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

