# NoDomainVitalSignsClinicalDescription-Extension - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsClinicalDescription-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsClinicalDescription-Extension 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsClinicalDescriptionExtension | *Version*:1.0.0 |
| Draft as of 2025-01-28 | *Computable Name*:NoDomainVitalSignsClinicalDescriptionExtension |

Narrative description about the pulse or heart beat.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [no-domain-VitalSigns-Observation-heartrate Profile](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.md), [no-domain-VitalSigns-Observation-pulse Profile](StructureDefinition-no-domain-VitalSigns-Observation-pulse.md) and [no-domain-VitalSigns-Observation-respirationrate Profile](StructureDefinition-no-domain-VitalSigns-Observation-respirationrate.md)
* Examples for this Extension: [Observation/no-heart-rate-create](Observation-no-heart-rate-create.md), [Observation/no-pulse-rate](Observation-no-pulse-rate.md) and [Observation/no-respiratory-rate-create](Observation-no-respiratory-rate-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/NoDomainVitalSignsClinicalDescriptionExtension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Annotation: Narrative description about the pulse or heart beat.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Annotation: Narrative description about the pulse or heart beat.

 

Other representations of profile: [CSV](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.csv), [Excel](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.xlsx), [Schematron](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.sch) 

#### Constraints

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

