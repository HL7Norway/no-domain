# NoDomainVitalSignsClinicalDescription-Extension - TTL Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsClinicalDescription-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.profile.json.md) 
*  [TTL](#) 

## Extension: NoDomainVitalSignsClinicalDescriptionExtension - TTL Profile

| |
| :--- |
| Draft as of 2025-01-28 |

TTL representation of the NoDomainVitalSignsClinicalDescriptionExtension extension.

[Raw ttl](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.ttl) | [Download](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

