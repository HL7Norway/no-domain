# NoDomainVitalSignsClinicalDescription-Extension - XML Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsClinicalDescription-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsClinicalDescriptionExtension - XML Profile

| |
| :--- |
| Draft as of 2025-01-28 |

XML representation of the NoDomainVitalSignsClinicalDescriptionExtension extension.

[Raw xml](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.xml) | [Download](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

