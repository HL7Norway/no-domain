# NoDomainVitalSignsClothingState-Extension - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsClothingState-Extension**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsClothingStateExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsClothingStateExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsClothingStateExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsClothingStateExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsClothingStateExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsClothingState-Extension 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsClothingStateExtension | *Version*:0.9.0 |
| Draft as of 2025-01-28 | *Computable Name*:NoDomainVitalSignsClothingStateExtension |

Description of the state of dress of the person at the time of weighing.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [no-domain-VitalSigns-Observation-bodyweight Profile](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.md)
* Examples for this Extension: [Observation/no-body-weight-create](Observation-no-body-weight-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/NoDomainVitalSignsClothingStateExtension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Coding: Description of the state of dress of the person at the time of weighing.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Coding: Description of the state of dress of the person at the time of weighing.

 

Other representations of profile: [CSV](StructureDefinition-NoDomainVitalSignsClothingStateExtension.csv), [Excel](StructureDefinition-NoDomainVitalSignsClothingStateExtension.xlsx), [Schematron](StructureDefinition-NoDomainVitalSignsClothingStateExtension.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

