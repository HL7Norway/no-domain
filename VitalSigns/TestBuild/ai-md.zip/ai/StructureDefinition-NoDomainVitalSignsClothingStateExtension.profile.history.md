#  - v1.0.0

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsClothingStateExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsClothingStateExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsClothingStateExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsClothingStateExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsClothingStateExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsClothingStateExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsClothingStateExtension - Change History

| |
| :--- |
| Draft as of 2025-01-28 |

Changes in the NoDomainVitalSignsClothingStateExtension extension.

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

