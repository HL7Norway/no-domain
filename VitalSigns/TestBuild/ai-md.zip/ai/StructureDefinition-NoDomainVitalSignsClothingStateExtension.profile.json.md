# NoDomainVitalSignsClothingState-Extension - JSON Representation - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsClothingState-Extension**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsClothingStateExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsClothingStateExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsClothingStateExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsClothingStateExtension.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-NoDomainVitalSignsClothingStateExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsClothingStateExtension - JSON Profile

| |
| :--- |
| Draft as of 2025-01-28 |

JSON representation of the NoDomainVitalSignsClothingStateExtension extension.

[Raw json](StructureDefinition-NoDomainVitalSignsClothingStateExtension.json) | [Download](StructureDefinition-NoDomainVitalSignsClothingStateExtension.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

