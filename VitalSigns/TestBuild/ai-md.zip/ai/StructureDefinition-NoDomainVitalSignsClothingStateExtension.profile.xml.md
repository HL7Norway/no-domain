# NoDomainVitalSignsClothingState-Extension - XML Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsClothingState-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsClothingStateExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsClothingStateExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsClothingStateExtension-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-NoDomainVitalSignsClothingStateExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsClothingStateExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsClothingStateExtension - XML Profile

| |
| :--- |
| Draft as of 2025-01-28 |

XML representation of the NoDomainVitalSignsClothingStateExtension extension.

[Raw xml](StructureDefinition-NoDomainVitalSignsClothingStateExtension.xml) | [Download](StructureDefinition-NoDomainVitalSignsClothingStateExtension.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

