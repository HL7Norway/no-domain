# NoDomainVitalSignsConfoundingFactor-Extension - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsConfoundingFactor-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsConfoundingFactor-Extension 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsConfoundingFactorExtension | *Version*:0.9.5 |
| Draft as of 2025-01-28 | *Computable Name*:NoDomainVitalSignsConfoundingFactorExtension |

Confounding factor is Issues or factors that may impact on the measurement, not captured in other fields

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [no-domain-VitalSigns-Observation-bloodpressure Profile](StructureDefinition-no-domain-VitalSigns-Observation-bloodpressure.md), [no-domain-VitalSigns-Observation-bodyheight Profile](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight.md), [no-domain-VitalSigns-Observation-bodytemp Profile](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.md), [no-domain-VitalSigns-Observation-bodyweight Profile](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.md)...Show 4 more,[no-domain-VitalSigns-Observation-heartrate Profile](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.md),[no-domain-VitalSigns-Observation-oxygensaturation Profile](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.md),[no-domain-VitalSigns-Observation-pulse Profile](StructureDefinition-no-domain-VitalSigns-Observation-pulse.md)and[no-domain-VitalSigns-Observation-respirationrate Profile](StructureDefinition-no-domain-VitalSigns-Observation-respirationrate.md)
* Examples for this Extension: [Observation/no-body-height-create](Observation-no-body-height-create.md), [Observation/no-body-weight-create](Observation-no-body-weight-create.md), [Observation/no-heart-rate-create](Observation-no-heart-rate-create.md), [Observation/no-oxygen-saturation-create](Observation-no-oxygen-saturation-create.md)...Show 2 more,[Observation/no-pulse-rate](Observation-no-pulse-rate.md)and[Observation/no-respiratory-rate-create](Observation-no-respiratory-rate-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/NoDomainVitalSignsConfoundingFactorExtension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Confounding factor is Issues or factors that may impact on the measurement, not captured in other fields

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type CodeableConcept: Confounding factor is Issues or factors that may impact on the measurement, not captured in other fields

 

Other representations of profile: [CSV](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.csv), [Excel](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.xlsx), [Schematron](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.sch) 

#### Constraints

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

