# NoDomainVitalSignsConfoundingFactor-Extension - JSON Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsConfoundingFactor-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsConfoundingFactorExtension - JSON Profile

| |
| :--- |
| Draft as of 2025-01-28 |

JSON representation of the NoDomainVitalSignsConfoundingFactorExtension extension.

[Raw json](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.json) | [Download](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

