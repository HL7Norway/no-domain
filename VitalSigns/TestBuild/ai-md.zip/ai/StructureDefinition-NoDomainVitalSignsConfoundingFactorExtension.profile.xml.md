# NoDomainVitalSignsConfoundingFactor-Extension - XML Representation - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsConfoundingFactor-Extension**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsConfoundingFactorExtension - XML Profile

| |
| :--- |
| Draft as of 2025-01-28 |

XML representation of the NoDomainVitalSignsConfoundingFactorExtension extension.

[Raw xml](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.xml) | [Download](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

