# NoDomainVitalSignsCuffSize-Extension - Definitions - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsCuffSize-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsCuffSizeExtension.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsCuffSizeExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsCuffSizeExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsCuffSizeExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsCuffSizeExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsCuffSizeExtension - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-01-28 |

Definitions for the NoDomainVitalSignsCuffSizeExtension extension.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

