# NoDomainVitalSignsCuffSize-Extension - TTL Representation - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsCuffSize-Extension**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsCuffSizeExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsCuffSizeExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsCuffSizeExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsCuffSizeExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsCuffSizeExtension.profile.json.md) 
*  [TTL](#) 

## Extension: NoDomainVitalSignsCuffSizeExtension - TTL Profile

| |
| :--- |
| Draft as of 2025-01-28 |

TTL representation of the NoDomainVitalSignsCuffSizeExtension extension.

[Raw ttl](StructureDefinition-NoDomainVitalSignsCuffSizeExtension.ttl) | [Download](StructureDefinition-NoDomainVitalSignsCuffSizeExtension.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

