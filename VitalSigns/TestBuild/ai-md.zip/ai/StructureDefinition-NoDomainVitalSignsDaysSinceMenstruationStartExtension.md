# NoDomainVitalSignsDaysSinceMenstruationStart-Extension - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsDaysSinceMenstruationStart-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsDaysSinceMenstruationStart-Extension 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsDaysSinceMenstruationStartExtension | *Version*:1.0.0 |
| Draft as of 2025-01-28 | *Computable Name*:NoDomainVitalSignsDaysSinceMenstruationStartExtension |

Current day of the menstrual cycle.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [no-domain-VitalSigns-Observation-bodytemp Profile](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.md)
* Examples for this Extension: [Observation/no-body-temperature-create](Observation-no-body-temperature-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/NoDomainVitalSignsDaysSinceMenstruationStartExtension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type positiveInt: Current day of the menstrual cycle.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type positiveInt: Current day of the menstrual cycle.

 

Other representations of profile: [CSV](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.csv), [Excel](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.xlsx), [Schematron](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.sch) 

#### Constraints

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

