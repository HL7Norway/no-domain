# NoDomainVitalSignsDaysSinceMenstruationStart-Extension - JSON Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsDaysSinceMenstruationStart-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsDaysSinceMenstruationStartExtension - JSON Profile

| |
| :--- |
| Draft as of 2025-01-28 |

JSON representation of the NoDomainVitalSignsDaysSinceMenstruationStartExtension extension.

[Raw json](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.json) | [Download](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

