# NoDomainVitalSignsDiastolicEndPoint-Extension - Testing - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsDiastolicEndPoint-Extension**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsDiastolicEndPointExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsDiastolicEndPointExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsDiastolicEndPointExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsDiastolicEndPointExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsDiastolicEndPointExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsDiastolicEndPointExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsDiastolicEndPointExtension - Testing

| |
| :--- |
| Draft as of 2021-05-01 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

