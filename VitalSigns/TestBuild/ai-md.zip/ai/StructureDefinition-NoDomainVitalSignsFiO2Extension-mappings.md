# NoDomainVitalSignsFiO2-Extension - Mappings - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsFiO2-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsFiO2Extension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsFiO2Extension-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.ttl.md) 

## Extension: NoDomainVitalSignsFiO2Extension - Mappings

| |
| :--- |
| Draft as of 2025-10-05 |

Mappings for the NoDomainVitalSignsFiO2Extension extension.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

