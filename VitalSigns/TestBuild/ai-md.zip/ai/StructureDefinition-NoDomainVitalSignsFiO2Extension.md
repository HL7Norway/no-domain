# NoDomainVitalSignsFiO2-Extension - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsFiO2-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsFiO2Extension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsFiO2Extension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.ttl.md) 

## Extension: NoDomainVitalSignsFiO2-Extension 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsFiO2Extension | *Version*:1.0.0 |
| Draft as of 2025-10-05 | *Computable Name*:NoDomainVitalSignsFiO2Extension |

Fraction of oxygen in inspired air.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [NoDomainVitalSignsInspiredOxygen-Extension](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension.md)
* Examples for this Extension: [Observation/no-oxygen-saturation-create](Observation-no-oxygen-saturation-create.md) and [Observation/no-respiratory-rate-create](Observation-no-respiratory-rate-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/NoDomainVitalSignsFiO2Extension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Ratio: Fraction of oxygen in inspired air.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Ratio: Fraction of oxygen in inspired air.

 

Other representations of profile: [CSV](StructureDefinition-NoDomainVitalSignsFiO2Extension.csv), [Excel](StructureDefinition-NoDomainVitalSignsFiO2Extension.xlsx), [Schematron](StructureDefinition-NoDomainVitalSignsFiO2Extension.sch) 

#### Constraints

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

