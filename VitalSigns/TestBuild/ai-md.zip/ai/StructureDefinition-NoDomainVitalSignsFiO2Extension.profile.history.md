#  - v0.9.5

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsFiO2Extension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsFiO2Extension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsFiO2Extension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.ttl.md) 

## Extension: NoDomainVitalSignsFiO2Extension - Change History

| |
| :--- |
| Draft as of 2025-10-06 |

Changes in the NoDomainVitalSignsFiO2Extension extension.

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

