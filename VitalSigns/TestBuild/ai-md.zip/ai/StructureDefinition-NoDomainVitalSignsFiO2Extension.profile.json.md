# NoDomainVitalSignsFiO2-Extension - JSON Representation - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsFiO2-Extension**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsFiO2Extension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsFiO2Extension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsFiO2Extension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.ttl.md) 

## Extension: NoDomainVitalSignsFiO2Extension - JSON Profile

| |
| :--- |
| Draft as of 2025-10-05 |

JSON representation of the NoDomainVitalSignsFiO2Extension extension.

[Raw json](StructureDefinition-NoDomainVitalSignsFiO2Extension.json) | [Download](StructureDefinition-NoDomainVitalSignsFiO2Extension.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

