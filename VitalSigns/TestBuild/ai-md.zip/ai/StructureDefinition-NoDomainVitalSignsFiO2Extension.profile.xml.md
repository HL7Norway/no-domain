# NoDomainVitalSignsFiO2-Extension - XML Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsFiO2-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsFiO2Extension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsFiO2Extension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsFiO2Extension-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsFiO2Extension.profile.ttl.md) 

## Extension: NoDomainVitalSignsFiO2Extension - XML Profile

| |
| :--- |
| Draft as of 2025-10-05 |

XML representation of the NoDomainVitalSignsFiO2Extension extension.

[Raw xml](StructureDefinition-NoDomainVitalSignsFiO2Extension.xml) | [Download](StructureDefinition-NoDomainVitalSignsFiO2Extension.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

