#  - v0.9.5

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsFlowExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsFlowExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsFlowExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsFlowExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsFlowExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsFlowExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsFlowExtension - Change History

| |
| :--- |
| Draft as of 2025-10-06 |

Changes in the NoDomainVitalSignsFlowExtension extension.

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

