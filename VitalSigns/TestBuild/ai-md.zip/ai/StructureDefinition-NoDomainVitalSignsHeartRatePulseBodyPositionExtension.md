# NoDomainVitalSignsHeartRatePulseBodyPosition-Extension - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsHeartRatePulseBodyPosition-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsHeartRatePulseBodyPositionExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsHeartRatePulseBodyPositionExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsHeartRatePulseBodyPositionExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsHeartRatePulseBodyPositionExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsHeartRatePulseBodyPositionExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsHeartRatePulseBodyPosition-Extension 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsHeartRatePulseBodyPositionExtension | *Version*:0.9.5 |
| Draft as of 2025-01-28 | *Computable Name*:NoDomainVitalSignsHeartRatePulseBodyPositionExtension |

Record which Korotkoff sound is used for determining diastolic pressure using auscultative method.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [no-domain-VitalSigns-Observation-heartrate Profile](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.md) and [no-domain-VitalSigns-Observation-pulse Profile](StructureDefinition-no-domain-VitalSigns-Observation-pulse.md)
* Examples for this Extension: [Observation/no-heart-rate-create](Observation-no-heart-rate-create.md) and [Observation/no-pulse-rate](Observation-no-pulse-rate.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/NoDomainVitalSignsHeartRatePulseBodyPositionExtension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Coding: Record which Korotkoff sound is used for determining diastolic pressure using auscultative method.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Coding: Record which Korotkoff sound is used for determining diastolic pressure using auscultative method.

 

Other representations of profile: [CSV](StructureDefinition-NoDomainVitalSignsHeartRatePulseBodyPositionExtension.csv), [Excel](StructureDefinition-NoDomainVitalSignsHeartRatePulseBodyPositionExtension.xlsx), [Schematron](StructureDefinition-NoDomainVitalSignsHeartRatePulseBodyPositionExtension.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

