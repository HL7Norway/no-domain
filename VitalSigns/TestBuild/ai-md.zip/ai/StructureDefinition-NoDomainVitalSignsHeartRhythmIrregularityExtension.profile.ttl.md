# NoDomainVitalSignsHeartRhythmIrregularity-Extension - TTL Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsHeartRhythmIrregularity-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension.profile.json.md) 
*  [TTL](#) 

## Extension: NoDomainVitalSignsHeartRhythmIrregularityExtension - TTL Profile

| |
| :--- |
| Draft as of 2025-01-28 |

TTL representation of the NoDomainVitalSignsHeartRhythmIrregularityExtension extension.

[Raw ttl](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension.ttl) | [Download](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

