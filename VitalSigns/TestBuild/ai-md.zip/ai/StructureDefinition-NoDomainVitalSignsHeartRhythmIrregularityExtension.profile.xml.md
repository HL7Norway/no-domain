# NoDomainVitalSignsHeartRhythmIrregularity-Extension - XML Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsHeartRhythmIrregularity-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsHeartRhythmIrregularityExtension - XML Profile

| |
| :--- |
| Draft as of 2025-01-28 |

XML representation of the NoDomainVitalSignsHeartRhythmIrregularityExtension extension.

[Raw xml](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension.xml) | [Download](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

