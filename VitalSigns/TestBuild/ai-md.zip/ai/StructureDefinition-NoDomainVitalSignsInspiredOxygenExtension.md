# NoDomainVitalSignsInspiredOxygen-Extension - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsInspiredOxygen-Extension**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsInspiredOxygen-Extension 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsInspiredOxygenExtension | *Version*:0.9.0 |
| Draft as of 2025-01-28 | *Computable Name*:NoDomainVitalSignsInspiredOxygenExtension |

Details of the amount of oxygen available to the subject at the time of observation.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [no-domain-VitalSigns-Observation-oxygensaturation Profile](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.md) and [no-domain-VitalSigns-Observation-respirationrate Profile](StructureDefinition-no-domain-VitalSigns-Observation-respirationrate.md)
* Examples for this Extension: [Observation/no-oxygen-saturation-create](Observation-no-oxygen-saturation-create.md) and [Observation/no-respiratory-rate-create](Observation-no-respiratory-rate-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/NoDomainVitalSignsInspiredOxygenExtension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Complex Extension: Details of the amount of oxygen available to the subject at the time of observation.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Complex Extension: Details of the amount of oxygen available to the subject at the time of observation.

 

Other representations of profile: [CSV](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension.csv), [Excel](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension.xlsx), [Schematron](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension.sch) 

#### Constraints

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

