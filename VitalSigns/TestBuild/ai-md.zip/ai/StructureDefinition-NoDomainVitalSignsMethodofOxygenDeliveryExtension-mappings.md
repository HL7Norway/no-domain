# NoDomainVitalSignsMethodofOxygenDelivery-Extension - Mappings - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsMethodofOxygenDelivery-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsMethodofOxygenDeliveryExtension - Mappings

| |
| :--- |
| Draft as of 2025-10-05 |

Mappings for the NoDomainVitalSignsMethodofOxygenDeliveryExtension extension.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

