# NoDomainVitalSignsMethodofOxygenDelivery-Extension - Testing - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsMethodofOxygenDelivery-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsMethodofOxygenDeliveryExtension - Testing

| |
| :--- |
| Draft as of 2025-10-06 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

