# NoDomainVitalSignsMethodofOxygenDelivery-Extension - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsMethodofOxygenDelivery-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsMethodofOxygenDelivery-Extension 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsMethodofOxygenDeliveryExtension | *Version*:0.9.5 |
| Draft as of 2025-10-06 | *Computable Name*:NoDomainVitalSignsMethodofOxygenDeliveryExtension |

The method used to deliver the oxygen.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [NoDomainVitalSignsInspiredOxygen-Extension](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension.md)
* Examples for this Extension: [Observation/no-oxygen-saturation-create](Observation-no-oxygen-saturation-create.md) and [Observation/no-respiratory-rate-create](Observation-no-respiratory-rate-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/NoDomainVitalSignsMethodofOxygenDeliveryExtension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type string: The method used to deliver the oxygen.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type string: The method used to deliver the oxygen.

 

Other representations of profile: [CSV](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.csv), [Excel](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.xlsx), [Schematron](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.sch) 

#### Constraints

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

