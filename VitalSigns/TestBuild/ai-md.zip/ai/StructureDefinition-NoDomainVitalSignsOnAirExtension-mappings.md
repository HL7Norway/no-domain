# NoDomainVitalSignsOnAir-Extension - Mappings - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsOnAir-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsOnAirExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsOnAirExtension-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-NoDomainVitalSignsOnAirExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsOnAirExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsOnAirExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsOnAirExtension - Mappings

| |
| :--- |
| Draft as of 2025-10-05 |

Mappings for the NoDomainVitalSignsOnAirExtension extension.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

