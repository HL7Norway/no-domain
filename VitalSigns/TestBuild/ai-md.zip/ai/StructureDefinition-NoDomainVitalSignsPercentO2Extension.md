# NoDomainVitalSignsPercentO2-Extension - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsPercentO2-Extension**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsPercentO2Extension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsPercentO2Extension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsPercentO2Extension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsPercentO2Extension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsPercentO2Extension.profile.ttl.md) 

## Extension: NoDomainVitalSignsPercentO2-Extension 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsPercentO2Extension | *Version*:0.9.0 |
| Draft as of 2025-10-05 | *Computable Name*:NoDomainVitalSignsPercentO2Extension |

Percentage of oxygen in inspired air.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [NoDomainVitalSignsInspiredOxygen-Extension](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension.md)
* Examples for this Extension: [Observation/no-oxygen-saturation-create](Observation-no-oxygen-saturation-create.md) and [Observation/no-respiratory-rate-create](Observation-no-respiratory-rate-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/NoDomainVitalSignsPercentO2Extension)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Ratio: Percentage of oxygen in inspired air.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Ratio: Percentage of oxygen in inspired air.

 

Other representations of profile: [CSV](StructureDefinition-NoDomainVitalSignsPercentO2Extension.csv), [Excel](StructureDefinition-NoDomainVitalSignsPercentO2Extension.xlsx), [Schematron](StructureDefinition-NoDomainVitalSignsPercentO2Extension.sch) 

#### Constraints

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

