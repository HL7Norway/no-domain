# NoDomainVitalSignsPercentO2-Extension - JSON Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsPercentO2-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsPercentO2Extension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsPercentO2Extension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsPercentO2Extension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsPercentO2Extension.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-NoDomainVitalSignsPercentO2Extension.profile.ttl.md) 

## Extension: NoDomainVitalSignsPercentO2Extension - JSON Profile

| |
| :--- |
| Draft as of 2025-10-05 |

JSON representation of the NoDomainVitalSignsPercentO2Extension extension.

[Raw json](StructureDefinition-NoDomainVitalSignsPercentO2Extension.json) | [Download](StructureDefinition-NoDomainVitalSignsPercentO2Extension.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

