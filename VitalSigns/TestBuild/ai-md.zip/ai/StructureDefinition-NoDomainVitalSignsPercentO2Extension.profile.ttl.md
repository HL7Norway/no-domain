# NoDomainVitalSignsPercentO2-Extension - TTL Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsPercentO2-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsPercentO2Extension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsPercentO2Extension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsPercentO2Extension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsPercentO2Extension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsPercentO2Extension.profile.json.md) 
*  [TTL](#) 

## Extension: NoDomainVitalSignsPercentO2Extension - TTL Profile

| |
| :--- |
| Draft as of 2025-10-06 |

TTL representation of the NoDomainVitalSignsPercentO2Extension extension.

[Raw ttl](StructureDefinition-NoDomainVitalSignsPercentO2Extension.ttl) | [Download](StructureDefinition-NoDomainVitalSignsPercentO2Extension.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

