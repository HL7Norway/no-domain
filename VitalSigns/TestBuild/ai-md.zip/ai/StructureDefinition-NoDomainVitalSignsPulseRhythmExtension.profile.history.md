#  - v1.0.0

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsPulseRhythmExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsPulseRhythmExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsPulseRhythmExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsPulseRhythmExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsPulseRhythmExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsPulseRhythmExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsPulseRhythmExtension - Change History

| |
| :--- |
| Draft as of 2021-05-01 |

Changes in the NoDomainVitalSignsPulseRhythmExtension extension.

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

