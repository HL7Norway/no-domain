#  - v0.9.5

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsPulseRhythmIrregularityExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsPulseRhythmIrregularityExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsPulseRhythmIrregularityExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsPulseRhythmIrregularityExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsPulseRhythmIrregularityExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsPulseRhythmIrregularityExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsPulseRhythmIrregularityExtension - Change History

| |
| :--- |
| Draft as of 2025-01-28 |

Changes in the NoDomainVitalSignsPulseRhythmIrregularityExtension extension.

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

