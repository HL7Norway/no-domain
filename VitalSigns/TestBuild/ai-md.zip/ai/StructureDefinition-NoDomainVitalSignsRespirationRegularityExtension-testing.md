# NoDomainVitalSignsRespirationRegularity-Extension - Testing - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsRespirationRegularity-Extension**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsRespirationRegularityExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsRespirationRegularityExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsRespirationRegularityExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsRespirationRegularityExtension.profile.xml.md) 
*  [JSON](StructureDefinition-NoDomainVitalSignsRespirationRegularityExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsRespirationRegularityExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsRespirationRegularityExtension - Testing

| |
| :--- |
| Draft as of 2025-01-28 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

