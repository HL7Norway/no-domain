# NoDomainVitalSignsSleepStatus-Extension - JSON Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsSleepStatus-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsSleepStatusExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsSleepStatusExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsSleepStatusExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsSleepStatusExtension.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-NoDomainVitalSignsSleepStatusExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsSleepStatusExtension - JSON Profile

| |
| :--- |
| Draft as of 2025-01-28 |

JSON representation of the NoDomainVitalSignsSleepStatusExtension extension.

[Raw json](StructureDefinition-NoDomainVitalSignsSleepStatusExtension.json) | [Download](StructureDefinition-NoDomainVitalSignsSleepStatusExtension.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

