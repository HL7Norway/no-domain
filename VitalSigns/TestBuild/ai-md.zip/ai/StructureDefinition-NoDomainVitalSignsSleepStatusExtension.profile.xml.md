# NoDomainVitalSignsSleepStatus-Extension - XML Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsSleepStatus-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsSleepStatusExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsSleepStatusExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsSleepStatusExtension-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-NoDomainVitalSignsSleepStatusExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsSleepStatusExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsSleepStatusExtension - XML Profile

| |
| :--- |
| Draft as of 2025-01-28 |

XML representation of the NoDomainVitalSignsSleepStatusExtension extension.

[Raw xml](StructureDefinition-NoDomainVitalSignsSleepStatusExtension.xml) | [Download](StructureDefinition-NoDomainVitalSignsSleepStatusExtension.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

