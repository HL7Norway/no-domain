# NoDomainVitalSignsSpontaneousBreathing-Extension - JSON Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsSpontaneousBreathing-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsSpontaneousBreathingExtension - JSON Profile

| |
| :--- |
| Draft as of 2025-01-28 |

JSON representation of the NoDomainVitalSignsSpontaneousBreathingExtension extension.

[Raw json](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension.json) | [Download](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

