# NoDomainVitalSignsSpontaneousBreathing-Extension - XML Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsSpontaneousBreathing-Extension**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension.profile.json.md) 
*  [TTL](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsSpontaneousBreathingExtension - XML Profile

| |
| :--- |
| Draft as of 2025-01-28 |

XML representation of the NoDomainVitalSignsSpontaneousBreathingExtension extension.

[Raw xml](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension.xml) | [Download](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

