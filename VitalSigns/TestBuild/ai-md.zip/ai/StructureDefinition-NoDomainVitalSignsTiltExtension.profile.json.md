# NoDomainVitalSignsTilt-Extension - JSON Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsTilt-Extension**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-NoDomainVitalSignsTiltExtension.md) 
*  [Detailed Descriptions](StructureDefinition-NoDomainVitalSignsTiltExtension-definitions.md) 
*  [Mappings](StructureDefinition-NoDomainVitalSignsTiltExtension-mappings.md) 
*  [XML](StructureDefinition-NoDomainVitalSignsTiltExtension.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-NoDomainVitalSignsTiltExtension.profile.ttl.md) 

## Extension: NoDomainVitalSignsTiltExtension - JSON Profile

| |
| :--- |
| Draft as of 2025-01-28 |

JSON representation of the NoDomainVitalSignsTiltExtension extension.

[Raw json](StructureDefinition-NoDomainVitalSignsTiltExtension.json) | [Download](StructureDefinition-NoDomainVitalSignsTiltExtension.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

