# no-domain-VitalSigns-Observation-bodyheight Profile - JSON Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-bodyheight Profile**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight.md) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight-definitions.md) 
*  [Mappings](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight-mappings.md) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight-examples.md) 
*  [XML](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight.profile.ttl.md) 

## Resource Profile: NoDomainVitalSignsObservationBodyHeight - JSON Profile

| |
| :--- |
| Draft as of 2025-01-28 |

JSON representation of the no-domain-VitalSigns-Observation-bodyheight resource profile.

[Raw json](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight.json) | [Download](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

