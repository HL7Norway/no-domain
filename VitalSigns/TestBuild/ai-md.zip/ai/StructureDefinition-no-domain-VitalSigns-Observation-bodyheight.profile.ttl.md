# no-domain-VitalSigns-Observation-bodyheight Profile - TTL Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-bodyheight Profile**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight.md) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight-definitions.md) 
*  [Mappings](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight-mappings.md) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight-examples.md) 
*  [XML](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight.profile.xml.md) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight.profile.json.md) 
*  [TTL](#) 

## Resource Profile: NoDomainVitalSignsObservationBodyHeight - TTL Profile

| |
| :--- |
| Draft as of 2025-01-28 |

TTL representation of the no-domain-VitalSigns-Observation-bodyheight resource profile.

[Raw ttl](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight.ttl) | [Download](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

