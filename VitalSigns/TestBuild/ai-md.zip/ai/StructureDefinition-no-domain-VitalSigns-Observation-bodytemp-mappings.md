# no-domain-VitalSigns-Observation-bodytemp Profile - Mappings - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-bodytemp Profile**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.md) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp-definitions.md) 
*  [Mappings](#) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp-examples.md) 
*  [XML](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.profile.xml.md) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.profile.json.md) 
*  [TTL](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.profile.ttl.md) 

## Resource Profile: NoDomainVitalSignsObservationBodyTemp - Mappings

| |
| :--- |
| Draft as of 2025-01-28 |

Mappings for the no-domain-VitalSigns-Observation-bodytemp resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

