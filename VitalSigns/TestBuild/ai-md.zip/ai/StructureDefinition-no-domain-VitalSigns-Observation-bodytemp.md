# no-domain-VitalSigns-Observation-bodytemp Profile - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-bodytemp Profile**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp-definitions.md) 
*  [Mappings](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp-mappings.md) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp-examples.md) 
*  [XML](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.profile.xml.md) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.profile.json.md) 
*  [TTL](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.profile.ttl.md) 

## Resource Profile: no-domain-VitalSigns-Observation-bodytemp Profile 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/no-domain-VitalSigns-Observation-bodytemp | *Version*:1.0.0 |
| Draft as of 2025-01-28 | *Computable Name*:NoDomainVitalSignsObservationBodyTemp |
| **Copyright/Legal**: Some content in this profile builds on the body temperature archetype: Kroppstemperatur, Publisert arketype [Internet]. openEHR Norge, Nasjonal IKT Clinical Knowledge Manager [sitert: 2024-12-04]. Hentet fra: https://arketyper.no/ckm/archetypes/1078.36.1855 | |

 
Domain profile for Norwegian Vital Signs Observation Body Temperature information. To be used for recording the measurement of an individual's body temperature. which is a surrogate for the core body temperature of the individual. 

 
Basisprofile for Norwegian VitalSigns Observation Body Temperature information. Defined by The Norwegian Directorate of eHealth and HL7 Norway. The profile adds Norwegian specific property information and further explanation of the use for the data-elements in a Norwegian VitalSigns Observation Body Temperature. 

**Usages:**

* Examples for this Profile: [Observation/no-body-temperature-create](Observation-no-body-temperature-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/no-domain-VitalSigns-Observation-bodytemp)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [observation-bodytemp](http://hl7.org/fhir/R4/bodytemp.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [observation-bodytemp](http://hl7.org/fhir/R4/bodytemp.html) 

**Summary**

Mandatory: 1 element(4 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [no-basis-Patient(http://hl7.no/fhir/StructureDefinition/no-basis-Patient)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Patient)
* [no-basis-Practitioner(http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)
* [no-basis-PractitionerRole(http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)
* [no-basis-Organization(http://hl7.no/fhir/StructureDefinition/no-basis-Organization)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Organization)

**Extensions**

This structure refers to these extensions:

* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsConfoundingFactorExtension](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsDaysSinceMenstruationStartExtension](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsBodyExposureExtension](StructureDefinition-NoDomainVitalSignsBodyExposureExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsActiveHeatingExtension](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.performer

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [observation-bodytemp](http://hl7.org/fhir/R4/bodytemp.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [observation-bodytemp](http://hl7.org/fhir/R4/bodytemp.html) 

**Summary**

Mandatory: 1 element(4 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [no-basis-Patient(http://hl7.no/fhir/StructureDefinition/no-basis-Patient)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Patient)
* [no-basis-Practitioner(http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)
* [no-basis-PractitionerRole(http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)
* [no-basis-Organization(http://hl7.no/fhir/StructureDefinition/no-basis-Organization)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Organization)

**Extensions**

This structure refers to these extensions:

* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsConfoundingFactorExtension](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsDaysSinceMenstruationStartExtension](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsBodyExposureExtension](StructureDefinition-NoDomainVitalSignsBodyExposureExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsActiveHeatingExtension](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.performer

 

Other representations of profile: [CSV](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.csv), [Excel](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.xlsx), [Schematron](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.sch) 

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

