# no-domain-VitalSigns-Observation-bodytemp Profile - TTL Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-bodytemp Profile**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.md) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp-definitions.md) 
*  [Mappings](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp-mappings.md) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp-examples.md) 
*  [XML](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.profile.xml.md) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.profile.json.md) 
*  [TTL](#) 

## Resource Profile: NoDomainVitalSignsObservationBodyTemp - TTL Profile

| |
| :--- |
| Draft as of 2025-01-28 |

TTL representation of the no-domain-VitalSigns-Observation-bodytemp resource profile.

[Raw ttl](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.ttl) | [Download](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.ttl)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

