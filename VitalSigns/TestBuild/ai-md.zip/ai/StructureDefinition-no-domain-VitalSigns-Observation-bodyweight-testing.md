# no-domain-VitalSigns-Observation-bodyweight Profile - Testing - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-bodyweight Profile**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.md) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight-definitions.md) 
*  [Mappings](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight-mappings.md) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight-examples.md) 
*  [XML](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.profile.xml.md) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.profile.json.md) 
*  [TTL](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.profile.ttl.md) 

## Resource Profile: NoDomainVitalSignsObservationBodyWeight - Testing

| |
| :--- |
| Draft as of 2025-01-28 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

