# no-domain-VitalSigns-Observation-bodyweight Profile - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-bodyweight Profile**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight-definitions.md) 
*  [Mappings](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight-mappings.md) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight-examples.md) 
*  [XML](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.profile.xml.md) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.profile.json.md) 
*  [TTL](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.profile.ttl.md) 

## Resource Profile: no-domain-VitalSigns-Observation-bodyweight Profile 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/no-domain-VitalSigns-Observation-bodyweight | *Version*:0.9.0 |
| Draft as of 2025-01-28 | *Computable Name*:NoDomainVitalSignsObservationBodyWeight |
| **Copyright/Legal**: Some content in this profile builds on the body weight archetype: Kroppsvekt, Publisert arketype [Internet]. openEHR Norge, Nasjonal IKT Clinical Knowledge Manager [sitert: 2024-12-04]. Hentet fra: https://arketyper.no/ckm/archetypes/1078.36.2273 | |

 
Domain profile for Norwegian Vital Signs Observation Body Weight information. To be used for recording the actual measurement of body weight, including when the individual is missing a body part due to a congenital cause or after surgical removal. 

 
To record the body weight of an individual - both actual and approximate. 

**Usages:**

* Examples for this Profile: [Observation/no-body-weight-create](Observation-no-body-weight-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/no-domain-VitalSigns-Observation-bodyweight)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [observation-bodyweight](http://hl7.org/fhir/R4/bodyweight.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [observation-bodyweight](http://hl7.org/fhir/R4/bodyweight.html) 

**Summary**

Mandatory: 1 element(2 nested mandatory elements)
 Fixed: 2 elements

**Structures**

This structure refers to these other structures:

* [no-basis-Patient(http://hl7.no/fhir/StructureDefinition/no-basis-Patient)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Patient)
* [no-basis-Practitioner(http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)
* [no-basis-PractitionerRole(http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)
* [no-basis-Organization(http://hl7.no/fhir/StructureDefinition/no-basis-Organization)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Organization)

**Extensions**

This structure refers to these extensions:

* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsClothingStateExtension](StructureDefinition-NoDomainVitalSignsClothingStateExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsConfoundingFactorExtension](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.performer
* The element 1 is sliced based on the value of Observation.value[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [observation-bodyweight](http://hl7.org/fhir/R4/bodyweight.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [observation-bodyweight](http://hl7.org/fhir/R4/bodyweight.html) 

**Summary**

Mandatory: 1 element(2 nested mandatory elements)
 Fixed: 2 elements

**Structures**

This structure refers to these other structures:

* [no-basis-Patient(http://hl7.no/fhir/StructureDefinition/no-basis-Patient)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Patient)
* [no-basis-Practitioner(http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)
* [no-basis-PractitionerRole(http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)
* [no-basis-Organization(http://hl7.no/fhir/StructureDefinition/no-basis-Organization)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Organization)

**Extensions**

This structure refers to these extensions:

* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsClothingStateExtension](StructureDefinition-NoDomainVitalSignsClothingStateExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsConfoundingFactorExtension](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.performer
* The element 1 is sliced based on the value of Observation.value[x]

 

Other representations of profile: [CSV](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.csv), [Excel](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.xlsx), [Schematron](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.sch) 

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

