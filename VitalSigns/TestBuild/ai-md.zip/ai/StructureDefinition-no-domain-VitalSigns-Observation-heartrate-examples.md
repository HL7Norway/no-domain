# no-domain-VitalSigns-Observation-heartrate Profile - Examples - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-heartrate Profile**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.md) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-heartrate-definitions.md) 
*  [Mappings](StructureDefinition-no-domain-VitalSigns-Observation-heartrate-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.profile.xml.md) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.profile.json.md) 
*  [TTL](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.profile.ttl.md) 

## Resource Profile: NoDomainVitalSignsObservationHeartRate - Examples

| |
| :--- |
| Draft as of 2025-01-28 |

Examples for the no-domain-VitalSigns-Observation-heartrate Profile.

| |
| :--- |
| [no-heart-rate-create](Observation-no-heart-rate-create.md) |

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

