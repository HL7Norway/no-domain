# no-domain-VitalSigns-Observation-heartrate Profile - Mappings - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-heartrate Profile**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.md) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-heartrate-definitions.md) 
*  [Mappings](#) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-heartrate-examples.md) 
*  [XML](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.profile.xml.md) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.profile.json.md) 
*  [TTL](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.profile.ttl.md) 

## Resource Profile: NoDomainVitalSignsObservationHeartRate - Mappings

| |
| :--- |
| Draft as of 2025-01-28 |

Mappings for the no-domain-VitalSigns-Observation-heartrate resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

