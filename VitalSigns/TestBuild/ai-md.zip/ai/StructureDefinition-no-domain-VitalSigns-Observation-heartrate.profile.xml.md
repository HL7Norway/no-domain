# no-domain-VitalSigns-Observation-heartrate Profile - XML Representation - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-heartrate Profile**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.md) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-heartrate-definitions.md) 
*  [Mappings](StructureDefinition-no-domain-VitalSigns-Observation-heartrate-mappings.md) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-heartrate-examples.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.profile.json.md) 
*  [TTL](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.profile.ttl.md) 

## Resource Profile: NoDomainVitalSignsObservationHeartRate - XML Profile

| |
| :--- |
| Draft as of 2025-01-28 |

XML representation of the no-domain-VitalSigns-Observation-heartrate resource profile.

[Raw xml](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.xml) | [Download](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

