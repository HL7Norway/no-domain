# no-domain-VitalSigns-Observation-oxygensaturation Profile - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-oxygensaturation Profile**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation-definitions.md) 
*  [Mappings](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation-mappings.md) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation-examples.md) 
*  [XML](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.profile.xml.md) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.profile.json.md) 
*  [TTL](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.profile.ttl.md) 

## Resource Profile: no-domain-VitalSigns-Observation-oxygensaturation Profile 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/no-domain-VitalSigns-Observation-oxygensaturation | *Version*:0.9.5 |
| Draft as of 2025-01-28 | *Computable Name*:NoDomainVitalSignsObservationOxygenSaturation |
| **Copyright/Legal**: Some content in this profile builds on the pulse oximetry archetype: Pulsoksymetri, Publisert arketype [Internet]. openEHR Norge, Nasjonal IKT Clinical Knowledge Manager [sitert: 2024-12-04]. Hentet fra: https://arketyper.no/ckm/archetypes/1078.36.53 | |

 
Domain profile for Norwegian Vital Signs Observation Oxygen Saturation information.
To be used for recording blood oxygen and related measurements, measured by pulse oximetry or pulse CO-oximetry. 

 
Basisprofile for Norwegian VitalSigns Observation Oxygen Saturation information. Defined by The Norwegian Directorate of eHealth and HL7 Norway. The profile adds Norwegian specific property information and further explanation of the use for the data-elements in a Norwegian VitalSigns Observation Oxygen Saturation. 

**Usages:**

* Examples for this Profile: [Observation/no-oxygen-saturation-create](Observation-no-oxygen-saturation-create.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/no-domain-VitalSigns-Observation-oxygensaturation)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [observation-oxygensat](http://hl7.org/fhir/R4/oxygensat.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [observation-oxygensat](http://hl7.org/fhir/R4/oxygensat.html) 

**Summary**

Mandatory: 1 element(2 nested mandatory elements)
 Fixed: 2 elements

**Structures**

This structure refers to these other structures:

* [no-basis-Patient(http://hl7.no/fhir/StructureDefinition/no-basis-Patient)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Patient)
* [no-basis-Practitioner(http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)
* [no-basis-PractitionerRole(http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)
* [no-basis-Organization(http://hl7.no/fhir/StructureDefinition/no-basis-Organization)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Organization)

**Extensions**

This structure refers to these extensions:

* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsInspiredOxygenExtension](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsConfoundingFactorExtension](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.performer

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [observation-oxygensat](http://hl7.org/fhir/R4/oxygensat.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [observation-oxygensat](http://hl7.org/fhir/R4/oxygensat.html) 

**Summary**

Mandatory: 1 element(2 nested mandatory elements)
 Fixed: 2 elements

**Structures**

This structure refers to these other structures:

* [no-basis-Patient(http://hl7.no/fhir/StructureDefinition/no-basis-Patient)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Patient)
* [no-basis-Practitioner(http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)
* [no-basis-PractitionerRole(http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)
* [no-basis-Organization(http://hl7.no/fhir/StructureDefinition/no-basis-Organization)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Organization)

**Extensions**

This structure refers to these extensions:

* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsInspiredOxygenExtension](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsConfoundingFactorExtension](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.performer

 

Other representations of profile: [CSV](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.csv), [Excel](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.xlsx), [Schematron](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.sch) 

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

