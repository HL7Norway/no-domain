# no-domain-VitalSigns-Observation-oxygensaturation Profile - XML Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-oxygensaturation Profile**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.md) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation-definitions.md) 
*  [Mappings](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation-mappings.md) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation-examples.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.profile.json.md) 
*  [TTL](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.profile.ttl.md) 

## Resource Profile: NoDomainVitalSignsObservationOxygenSaturation - XML Profile

| |
| :--- |
| Draft as of 2025-01-28 |

XML representation of the no-domain-VitalSigns-Observation-oxygensaturation resource profile.

[Raw xml](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.xml) | [Download](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

