# no-domain-VitalSigns-Observation-pulse Profile - v0.9.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **no-domain-VitalSigns-Observation-pulse Profile**

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-pulse-definitions.md) 
*  [Mappings](StructureDefinition-no-domain-VitalSigns-Observation-pulse-mappings.md) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-pulse-examples.md) 
*  [XML](StructureDefinition-no-domain-VitalSigns-Observation-pulse.profile.xml.md) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-pulse.profile.json.md) 
*  [TTL](StructureDefinition-no-domain-VitalSigns-Observation-pulse.profile.ttl.md) 

## Resource Profile: no-domain-VitalSigns-Observation-pulse Profile 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/no-domain-VitalSigns-Observation-pulse | *Version*:0.9.0 |
| Draft as of 2025-01-28 | *Computable Name*:NoDomainVitalSignsObservationPulse |
| **Copyright/Legal**: Some content in this profile builds on the heart rate archetype: Puls/Hjertefrekvens, Publisert arketype [Internet]. openEHR Norge, Nasjonal IKT Clinical Knowledge Manager [sitert: 2024-12-04]. Hentet fra: https://arketyper.no/ckm/archetypes/1078.36.2293 | |

 
Domain profile for Norwegian Vital Signs Observation Pulse information. To be used for recording the number of times your arteries create a noticeable pulse due to increase in blood pressure. This profile describes how to use a SNOMED code to indicate that the measurement is actually a pulse measurement at systemic artery, and not a general heart rate measurement that can be measured both as pulse and the actual heart beat. 

 
Basisprofile for Norwegian VitalSigns Observation pulse information. Defined by The Norwegian Directorate of eHealth and HL7 Norway. The profile adds Norwegian specific property information and further explanation of the use for the data-elements in a Norwegian VitalSigns Observation Pulse. 

**Usages:**

* Examples for this Profile: [Observation/no-pulse-rate](Observation-no-pulse-rate.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.domain.vitalsigns|current/StructureDefinition/no-domain-VitalSigns-Observation-pulse)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [observation-heartrate](http://hl7.org/fhir/R4/heartrate.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [observation-heartrate](http://hl7.org/fhir/R4/heartrate.html) 

**Summary**

Mandatory: 1 element(2 nested mandatory elements)
 Fixed: 2 elements

**Structures**

This structure refers to these other structures:

* [no-basis-Patient(http://hl7.no/fhir/StructureDefinition/no-basis-Patient)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Patient)
* [no-basis-Practitioner(http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)
* [no-basis-PractitionerRole(http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)
* [no-basis-Organization(http://hl7.no/fhir/StructureDefinition/no-basis-Organization)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Organization)

**Extensions**

This structure refers to these extensions:

* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsPulseRhythmExtension](StructureDefinition-NoDomainVitalSignsPulseRhythmExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsConfoundingFactorExtension](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsClinicalDescriptionExtension](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsCharacterOfPulseExtension](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsHeartRatePulseBodyPositionExtension](StructureDefinition-NoDomainVitalSignsHeartRatePulseBodyPositionExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsPulseRhythmIrregularityExtension](StructureDefinition-NoDomainVitalSignsPulseRhythmIrregularityExtension.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.performer
* The element 1 is sliced based on the value of Observation.value[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [observation-heartrate](http://hl7.org/fhir/R4/heartrate.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [observation-heartrate](http://hl7.org/fhir/R4/heartrate.html) 

**Summary**

Mandatory: 1 element(2 nested mandatory elements)
 Fixed: 2 elements

**Structures**

This structure refers to these other structures:

* [no-basis-Patient(http://hl7.no/fhir/StructureDefinition/no-basis-Patient)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Patient)
* [no-basis-Practitioner(http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Practitioner)
* [no-basis-PractitionerRole(http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-PractitionerRole)
* [no-basis-Organization(http://hl7.no/fhir/StructureDefinition/no-basis-Organization)](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Organization)

**Extensions**

This structure refers to these extensions:

* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsPulseRhythmExtension](StructureDefinition-NoDomainVitalSignsPulseRhythmExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsConfoundingFactorExtension](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsClinicalDescriptionExtension](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsCharacterOfPulseExtension](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsHeartRatePulseBodyPositionExtension](StructureDefinition-NoDomainVitalSignsHeartRatePulseBodyPositionExtension.md)
* [http://hl7.no/fhir/no-domain/vitalsigns/StructureDefinition/NoDomainVitalSignsPulseRhythmIrregularityExtension](StructureDefinition-NoDomainVitalSignsPulseRhythmIrregularityExtension.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.performer
* The element 1 is sliced based on the value of Observation.value[x]

 

Other representations of profile: [CSV](StructureDefinition-no-domain-VitalSigns-Observation-pulse.csv), [Excel](StructureDefinition-no-domain-VitalSigns-Observation-pulse.xlsx), [Schematron](StructureDefinition-no-domain-VitalSigns-Observation-pulse.sch) 

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

