#  - v0.9.0

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Content](StructureDefinition-no-domain-VitalSigns-Observation-respirationrate.md) 
*  [Detailed Descriptions](StructureDefinition-no-domain-VitalSigns-Observation-respirationrate-definitions.md) 
*  [Mappings](StructureDefinition-no-domain-VitalSigns-Observation-respirationrate-mappings.md) 
*  [Examples](StructureDefinition-no-domain-VitalSigns-Observation-respirationrate-examples.md) 
*  [XML](StructureDefinition-no-domain-VitalSigns-Observation-respirationrate.profile.xml.md) 
*  [JSON](StructureDefinition-no-domain-VitalSigns-Observation-respirationrate.profile.json.md) 
*  [TTL](StructureDefinition-no-domain-VitalSigns-Observation-respirationrate.profile.ttl.md) 

## Resource Profile: NoDomainVitalSignsObservationRespirationRate - Change History

| |
| :--- |
| Draft as of 2025-01-28 |

Changes in the no-domain-VitalSigns-Observation-respirationrate resource profile.

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

