#  - v0.9.0

NoDomainVitalSigns - Local Development build (v0.9.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](ValueSet-NoDomainVitalSignsBodyExposureValueSet.md) 
*  [XML](ValueSet-NoDomainVitalSignsBodyExposureValueSet.xml.md) 
*  [JSON](ValueSet-NoDomainVitalSignsBodyExposureValueSet.json.md) 
*  [TTL](ValueSet-NoDomainVitalSignsBodyExposureValueSet.ttl.md) 

## : NoDomainVitalSignsBodyExposureValueSet - Change History

History of changes for NoDomainVitalSignsBodyExposureValueSet .

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

