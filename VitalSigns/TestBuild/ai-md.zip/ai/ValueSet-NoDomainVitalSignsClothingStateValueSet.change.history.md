#  - v0.9.5

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](ValueSet-NoDomainVitalSignsClothingStateValueSet.md) 
*  [XML](ValueSet-NoDomainVitalSignsClothingStateValueSet.xml.md) 
*  [JSON](ValueSet-NoDomainVitalSignsClothingStateValueSet.json.md) 
*  [TTL](ValueSet-NoDomainVitalSignsClothingStateValueSet.ttl.md) 

## : NoDomainVitalSignsClothingStateValueSet - Change History

History of changes for NoDomainVitalSignsClothingStateValueSet .

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

