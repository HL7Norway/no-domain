# NoDomainVitalSignsCuffsize-ValueSet - JSON Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsCuffsize-ValueSet**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](ValueSet-NoDomainVitalSignsCuffsizeValueSet.md) 
*  [XML](ValueSet-NoDomainVitalSignsCuffsizeValueSet.xml.md) 
*  [JSON](#) 
*  [TTL](ValueSet-NoDomainVitalSignsCuffsizeValueSet.ttl.md) 

## : NoDomainVitalSignsCuffsize-ValueSet - JSON Representation

| | |
| :--- | :--- |
| *Page standards status:*[Draft](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 |

[Raw json](ValueSet-NoDomainVitalSignsCuffsizeValueSet.json) | [Download](ValueSet-NoDomainVitalSignsCuffsizeValueSet.json)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

