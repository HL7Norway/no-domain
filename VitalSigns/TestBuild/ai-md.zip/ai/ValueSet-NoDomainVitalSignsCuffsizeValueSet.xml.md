# NoDomainVitalSignsCuffsize-ValueSet - XML Representation - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsCuffsize-ValueSet**

NoDomainVitalSigns - Local Development build (v1.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](ValueSet-NoDomainVitalSignsCuffsizeValueSet.md) 
*  [XML](#) 
*  [JSON](ValueSet-NoDomainVitalSignsCuffsizeValueSet.json.md) 
*  [TTL](ValueSet-NoDomainVitalSignsCuffsizeValueSet.ttl.md) 

## : NoDomainVitalSignsCuffsize-ValueSet - XML Representation

| | |
| :--- | :--- |
| *Page standards status:*[Draft](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 |

[Raw xml](ValueSet-NoDomainVitalSignsCuffsizeValueSet.xml) | [Download](ValueSet-NoDomainVitalSignsCuffsizeValueSet.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#1.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-05 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

