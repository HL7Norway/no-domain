# NoDomainVitalSignsHeartRateMeasurementMethod-ValueSet - XML Representation - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsHeartRateMeasurementMethod-ValueSet**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](ValueSet-NoDomainVitalSignsHeartRateMeasurementMethodValueSet.md) 
*  [XML](#) 
*  [JSON](ValueSet-NoDomainVitalSignsHeartRateMeasurementMethodValueSet.json.md) 
*  [TTL](ValueSet-NoDomainVitalSignsHeartRateMeasurementMethodValueSet.ttl.md) 

## : NoDomainVitalSignsHeartRateMeasurementMethod-ValueSet - XML Representation

| | |
| :--- | :--- |
| *Page standards status:*[Draft](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 |

[Raw xml](ValueSet-NoDomainVitalSignsHeartRateMeasurementMethodValueSet.xml) | [Download](ValueSet-NoDomainVitalSignsHeartRateMeasurementMethodValueSet.xml)

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

