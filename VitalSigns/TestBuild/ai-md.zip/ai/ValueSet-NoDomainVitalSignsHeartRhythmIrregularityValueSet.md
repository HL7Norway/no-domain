# NoDomainVitalSignsHeartRhythmIrregularity-ValueSet - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsHeartRhythmIrregularity-ValueSet**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](#) 
*  [XML](ValueSet-NoDomainVitalSignsHeartRhythmIrregularityValueSet.xml.md) 
*  [JSON](ValueSet-NoDomainVitalSignsHeartRhythmIrregularityValueSet.json.md) 
*  [TTL](ValueSet-NoDomainVitalSignsHeartRhythmIrregularityValueSet.ttl.md) 

## ValueSet: NoDomainVitalSignsHeartRhythmIrregularity-ValueSet 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.no/fhir/no-domain/vitalsigns/ValueSet/NoDomainVitalSignsHeartRhythmIrregularityValueSet | *Version*:0.9.5 | |
| *Standards status:*[Draft](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:NoDomainVitalSignsHeartRhythmIrregularityValueSet |
| **Copyright/Legal**: This resource includes content from SNOMED Clinical Terms® (SNOMED CT®) which is copyright of the International Health Terminology Standards Development Organisation (IHTSDO). Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact http://www.snomed.org/snomed-ct/get-snomed-ct or info@snomed.org | | |

 
Codes representing heart rhythm irregularity for heart rate 

 **References** 

* [NoDomainVitalSignsHeartRhythmIrregularity-Extension](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension.md)

### Logical Definition (CLD)

Last updated: 2025-01-28 00:00:00+0000

Profile: [Shareable ValueSet](http://hl7.org/fhir/R4/shareablevalueset.html)

This value set includes codes based on the following rules:

* Include these codes as defined in [`http://snomed.info/sct`](http://www.snomed.org/) version 📍
* Include these codes as defined in [`http://snomed.info/sct`](http://www.snomed.org/) version Not Stated (use latest from terminology server) 

 

### Expansion

No Expansion for this valueset (Unsupported Code System Version)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

