# NoDomainVitalSignsPulseRhythmIrregularity-ValueSet - Testing - v0.9.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NoDomainVitalSignsPulseRhythmIrregularity-ValueSet**

NoDomainVitalSigns - Local Development build (v0.9.5) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/no-domain/vitalsigns/history.html)

*  [Narrative Content](ValueSet-NoDomainVitalSignsPulseRhythmIrregularityValueSet.md) 
*  [XML](ValueSet-NoDomainVitalSignsPulseRhythmIrregularityValueSet.xml.md) 
*  [JSON](ValueSet-NoDomainVitalSignsPulseRhythmIrregularityValueSet.json.md) 
*  [TTL](ValueSet-NoDomainVitalSignsPulseRhythmIrregularityValueSet.ttl.md) 

## ValueSet: NoDomainVitalSignsPulseRhythmIrregularity-ValueSet - Testing 

| | |
| :--- | :--- |
| *Page standards status:*[Draft](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 |

### Test Plans

**No test plans are currently available for the ValueSet.**

### Test Scripts

**No test scripts are currently available for the ValueSet.**

 IG © 2024+ [HL7 Norway](http://www.hl7.no). Package hl7.fhir.no.domain.vitalsigns#0.9.5 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

