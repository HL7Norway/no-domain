# hl7.fhir.no.domain.vitalsigns#0.9.6: null

## Pages

* [Home](index.md)
* [Download](download.md)
* [Licence Legal](licence_legal.md)
* [VKP Mapping](VKP-mapping.md)
* [Guidance](guidance.md)
* [Artifacts Summary](artifacts.md)

## Resources

### ValueSets

* [NoDomainVitalSignsBloodPressureMeasurementMethod-ValueSet](ValueSet-NoDomainVitalSignsBloodPressureMeasurementMethodValueSet.md)
* [NoDomainVitalSignsBloodpressureBodyPosition-ValueSet](ValueSet-NoDomainVitalSignsBloodpressureBodyPositionValueSet.md)
* [NoDomainVitalSignsBloodpressureBodySite-ValueSet](ValueSet-NoDomainVitalSignsBloodpressureBodySiteValueSet.md)
* [NoDomainVitalSignsBodyExposure-ValueSet](ValueSet-NoDomainVitalSignsBodyExposureValueSet.md)
* [NoDomainVitalSignsBodyHeightBodyPosition-ValueSet](ValueSet-NoDomainVitalSignsBodyHeightBodyPositionValueSet.md)
* [NoDomainVitalSignsBodyTempBodySite-ValueSet](ValueSet-NoDomainVitalSignsBodyTempBodySiteValueSet.md)
* [NoDomainVitalSignsClothingState-ValueSet](ValueSet-NoDomainVitalSignsClothingStateValueSet.md)
* [NoDomainVitalSignsCuffsize-ValueSet](ValueSet-NoDomainVitalSignsCuffsizeValueSet.md)
* [NoDomainVitalSignsDiastolicendPoint-ValueSet](ValueSet-NoDomainVitalSignsDiastolicEndPointValueSet.md)
* [NoDomainVitalSignsHeartRateBodySite-ValueSet](ValueSet-NoDomainVitalSignsHeartRateBodySiteValueSet.md)
* [NoDomainVitalSignsHeartRateMeasurementMethod-ValueSet](ValueSet-NoDomainVitalSignsHeartRateMeasurementMethodValueSet.md)
* [NoDomainVitalSignsHeartRatePulseBodyPosition-ValueSet](ValueSet-NoDomainVitalSignsHeartRatePulseBodyPositionValueSet.md)
* [NoDomainVitalSignsHeartRhythmIrregularity-ValueSet](ValueSet-NoDomainVitalSignsHeartRhythmIrregularityValueSet.md)
* [NoDomainVitalSignsPulseBodySite-ValueSet](ValueSet-NoDomainVitalSignsPulseBodySiteValueSet.md)
* [NoDomainVitalSignsPulseMeasurementMethod-ValueSet](ValueSet-NoDomainVitalSignsPulseMeasurementMethodValueSet.md)
* [NoDomainVitalSignsPulseRhythmIrregularity-ValueSet](ValueSet-NoDomainVitalSignsPulseRhythmIrregularityValueSet.md)
* [NoDomainVitalSignsPulseRhythm-ValueSet](ValueSet-NoDomainVitalSignsPulseRhythmValueSet.md)
* [NoDomainVitalSignsRespirationRateBodyPosition-ValueSet](ValueSet-NoDomainVitalSignsRespirationRateBodyPositionValueSet.md)
* [NoDomainVitalSignsRespirationRateDepth-ValueSet](ValueSet-NoDomainVitalSignsRespirationRateDepthValueSet.md)
* [NoDomainVitalSignsRespirationRegularity-ValueSet](ValueSet-NoDomainVitalSignsRespirationRegularityValueSet.md)
* [NoDomainVitalSignsSleepStatus-ValueSet](ValueSet-NoDomainVitalSignsSleepStatusValueSet.md)
* [NoDomainVitalSignsSpontaneousBreathing-ValueSet](ValueSet-NoDomainVitalSignsSpontaneousBreathingValueSet.md)

### Resource Profiles

* [no-domain-VitalSigns-Observation-bloodpressure Profile](StructureDefinition-no-domain-VitalSigns-Observation-bloodpressure.md)
* [no-domain-VitalSigns-Observation-bodyheight Profile](StructureDefinition-no-domain-VitalSigns-Observation-bodyheight.md)
* [no-domain-VitalSigns-Observation-bodytemp Profile](StructureDefinition-no-domain-VitalSigns-Observation-bodytemp.md)
* [no-domain-VitalSigns-Observation-bodyweight Profile](StructureDefinition-no-domain-VitalSigns-Observation-bodyweight.md)
* [no-domain-VitalSigns-Observation-heartrate Profile](StructureDefinition-no-domain-VitalSigns-Observation-heartrate.md)
* [no-domain-VitalSigns-Observation-oxygensaturation Profile](StructureDefinition-no-domain-VitalSigns-Observation-oxygensaturation.md)
* [no-domain-VitalSigns-Observation-pulse Profile](StructureDefinition-no-domain-VitalSigns-Observation-pulse.md)
* [no-domain-VitalSigns-Observation-respirationrate Profile](StructureDefinition-no-domain-VitalSigns-Observation-respirationrate.md)

### Extensions

* [NoDomainVitalSignsActiveHeating-Extension](StructureDefinition-NoDomainVitalSignsActiveHeatingExtension.md)
* [NoDomainVitalSignsBloodpressureBodyPosition-Extension](StructureDefinition-NoDomainVitalSignsBloodpressureBodyPositionExtension.md)
* [NoDomainVitalSignsBloodpressureDiastolicFormula-Extension](StructureDefinition-NoDomainVitalSignsBloodpressureDiastolicFormulaExtension.md)
* [NoDomainVitalSignsBloodpressureMeanArterialFormula-Extension](StructureDefinition-NoDomainVitalSignsBloodpressureMeanArterialFormulaExtension.md)
* [NoDomainVitalSignsBloodpressureSystolicFormula-Extension](StructureDefinition-NoDomainVitalSignsBloodpressureSystolicFormulaExtension.md)
* [NoDomainVitalSignsBodyExposure-Extension](StructureDefinition-NoDomainVitalSignsBodyExposureExtension.md)
* [NoDomainVitalSignsBodyHeightBodyPosition-Extension](StructureDefinition-NoDomainVitalSignsBodyHeightBodyPositionExtension.md)
* [NoDomainVitalSignsCharacterOfPulse-Extension](StructureDefinition-NoDomainVitalSignsCharacterOfPulseExtension.md)
* [NoDomainVitalSignsClinicalDescription-Extension](StructureDefinition-NoDomainVitalSignsClinicalDescriptionExtension.md)
* [NoDomainVitalSignsClothingState-Extension](StructureDefinition-NoDomainVitalSignsClothingStateExtension.md)
* [NoDomainVitalSignsConfoundingFactor-Extension](StructureDefinition-NoDomainVitalSignsConfoundingFactorExtension.md)
* [NoDomainVitalSignsCuffSize-Extension](StructureDefinition-NoDomainVitalSignsCuffSizeExtension.md)
* [NoDomainVitalSignsDaysSinceMenstruationStart-Extension](StructureDefinition-NoDomainVitalSignsDaysSinceMenstruationStartExtension.md)
* [NoDomainVitalSignsDiastolicEndPoint-Extension](StructureDefinition-NoDomainVitalSignsDiastolicEndPointExtension.md)
* [NoDomainVitalSignsFiO2-Extension](StructureDefinition-NoDomainVitalSignsFiO2Extension.md)
* [NoDomainVitalSignsFlow-Extension](StructureDefinition-NoDomainVitalSignsFlowExtension.md)
* [NoDomainVitalSignsHeartRatePulseBodyPosition-Extension](StructureDefinition-NoDomainVitalSignsHeartRatePulseBodyPositionExtension.md)
* [NoDomainVitalSignsHeartRhythmIrregularity-Extension](StructureDefinition-NoDomainVitalSignsHeartRhythmIrregularityExtension.md)
* [NoDomainVitalSignsInspiredOxygen-Extension](StructureDefinition-NoDomainVitalSignsInspiredOxygenExtension.md)
* [NoDomainVitalSignsMethodofOxygenDelivery-Extension](StructureDefinition-NoDomainVitalSignsMethodofOxygenDeliveryExtension.md)
* [NoDomainVitalSignsOnAir-Extension](StructureDefinition-NoDomainVitalSignsOnAirExtension.md)
* [NoDomainVitalSignsPercentO2-Extension](StructureDefinition-NoDomainVitalSignsPercentO2Extension.md)
* [NoDomainVitalSignsPulseRhythm-Extension](StructureDefinition-NoDomainVitalSignsPulseRhythmExtension.md)
* [NoDomainVitalSignsPulseRhythmIrregularity-Extension](StructureDefinition-NoDomainVitalSignsPulseRhythmIrregularityExtension.md)
* [NoDomainVitalSignsRespirationDepth-Extension](StructureDefinition-NoDomainVitalSignsRespirationDepthExtension.md)
* [NoDomainVitalSignsRespirationRateBodyPosition-Extension](StructureDefinition-NoDomainVitalSignsRespirationRateBodyPositionExtension.md)
* [NoDomainVitalSignsRespirationRegularity-Extension](StructureDefinition-NoDomainVitalSignsRespirationRegularityExtension.md)
* [NoDomainVitalSignsSleepStatus-Extension](StructureDefinition-NoDomainVitalSignsSleepStatusExtension.md)
* [NoDomainVitalSignsSpontaneousBreathing-Extension](StructureDefinition-NoDomainVitalSignsSpontaneousBreathingExtension.md)
* [NoDomainVitalSignsTilt-Extension](StructureDefinition-NoDomainVitalSignsTiltExtension.md)

### ImplementationGuides

* [NoDomainVitalSigns](index.md)

### Parameters

* [expansion](Parameters-expansion.md)

### Examples

* [no-blood-pressure-create (Observation)](Observation-no-blood-pressure-create.md)
* [no-body-height-create (Observation)](Observation-no-body-height-create.md)
* [no-body-temperature-create (Observation)](Observation-no-body-temperature-create.md)
* [no-body-weight-create (Observation)](Observation-no-body-weight-create.md)
* [no-heart-rate-create (Observation)](Observation-no-heart-rate-create.md)
* [no-oxygen-saturation-create (Observation)](Observation-no-oxygen-saturation-create.md)
* [no-pulse-rate (Observation)](Observation-no-pulse-rate.md)
* [no-respiratory-rate-create (Observation)](Observation-no-respiratory-rate-create.md)
* [afa23 (Organization)](Organization-afa23.md)
* [cdp1000240 (Patient)](Patient-cdp1000240.md)
* [cdp1000808 (Patient)](Patient-cdp1000808.md)
* [agb104 (PractitionerRole)](PractitionerRole-agb104.md)
* [agb30 (PractitionerRole)](PractitionerRole-agb30.md)
